<?php
class Company
{
    private $conn;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    // Create a new company
    public function create($data)
    {
        $query = "INSERT INTO company (
            name, email, phone, website, address,
            logo, industry, company_vat,
            statusId, created_by, updated_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $this->conn->prepare($query);
        $stmt->execute([
            $data->name,
            $data->email ?? null,
            $data->phone ?? null,
            $data->website ?? null,
            $data->address ?? null,
            $data->logo ?? null,
            $data->industry ?? null,
            $data->company_vat ?? null,
            $data->statusId ?? 1,
            $data->created_by ?? 0,
            $data->updated_by ?? 0
        ]);
        $id = $this->conn->lastInsertId();
        return $this->getById($id);
    }

    // Update company info
    public function update($data)
    {
        $query = "UPDATE company SET
            name = ?,
            email = ?,
            phone = ?,
            website = ?,
            address = ?,
            logo = ?,
            industry = ?,
            company_vat = ?,
            statusId = ?,
            updated_by = ?,
            updated_at = NOW()
        WHERE id = ?";

        $stmt = $this->conn->prepare($query);
        $success = $stmt->execute([
            $data->name,
            $data->email ?? null,
            $data->phone ?? null,
            $data->website ?? null,
            $data->address ?? null,
            $data->logo ?? null,
            $data->industry ?? null,
            $data->company_vat ?? null,
            $data->statusId ?? 1,
            $data->updated_by ?? 0,
            $data->id
        ]);
        return $success ? $this->getById($data->id) : false;
    }

    // Get single company by ID
    public function getById($id)
    {
        $stmt = $this->conn->prepare("SELECT * FROM company WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // List companies (optionally filter by statusId, industry, etc.)
    public function list($statusId = 1)
    {
        $stmt = $this->conn->prepare("SELECT * FROM company WHERE statusId = ? ORDER BY created_at DESC");
        $stmt->execute([$statusId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Delete company by ID
    public function delete($id)
    {
        $stmt = $this->conn->prepare("DELETE FROM company WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>
