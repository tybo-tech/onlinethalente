<?php
class User
{
    private $conn;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    // Check if user exists by email, website, and company
    public function userExistsByEmail($email, $websiteId, $companyId)
    {
        $stmt = $this->conn->prepare("SELECT id FROM User WHERE email = ? AND website_id = ? AND company_id = ?");
        $stmt->execute([$email, $websiteId, $companyId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Create a new user
    public function create($data)
    {
        $existing = $this->userExistsByEmail($data->email, $data->website_id, $data->company_id);
        if ($existing) {
            return $this->getById($existing['id']);
        }

        $query = "INSERT INTO User (
            name, email, password, role, phone, address,
            created_by, updated_by, statusId, website_id, company_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $this->conn->prepare($query);
        $hashedPassword = password_hash($data->password, PASSWORD_DEFAULT);
        $stmt->execute([
            $data->name,
            $data->email,
            $hashedPassword,
            $data->role,
            $data->phone,
            $data->address,
            $data->created_by,
            $data->updated_by,
            $data->statusId ?? 1,
            $data->website_id,
            $data->company_id
        ]);

        $id = $this->conn->lastInsertId();
        return $this->getById($id);
    }

    // Update user info
    public function update($data)
    {
        $query = "UPDATE User SET
            name = ?,
            role = ?,
            phone = ?,
            address = ?,
            updated_by = ?,
            updated_at = NOW(),
            statusId = ?,
            website_id = ?,
            company_id = ?
        WHERE id = ?";

        $stmt = $this->conn->prepare($query);
        $success = $stmt->execute([
            $data->name,
            $data->role,
            $data->phone,
            $data->address,
            $data->updated_by,
            $data->statusId ?? 1,
            $data->website_id,
            $data->company_id,
            $data->id
        ]);
        return $success ? $this->getById($data->id) : false;
    }

    // Get single user by ID (fetch company_id too)
    public function getById($id)
    {
        $stmt = $this->conn->prepare("SELECT id, name, email, role, phone, address, company_id, website_id, created_at, updated_at FROM User WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Get user by email, website, and company
    public function getByEmail($email, $websiteId, $companyId)
    {
        $stmt = $this->conn->prepare("SELECT * FROM User WHERE email = ? AND website_id = ? AND company_id = ?");
        $stmt->execute([$email, $websiteId, $companyId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Authenticate a user (website & company)
    public function authenticate($email, $password, $websiteId, $companyId)
    {
        $user = $this->getByEmail($email, $websiteId, $companyId);
        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        return false;
    }

    // List users for a specific website and company
    public function list($websiteId, $companyId)
    {
        $stmt = $this->conn->prepare("SELECT id, name, email, role, phone, statusId FROM User WHERE website_id = ? AND company_id = ? ORDER BY created_at DESC");
        $stmt->execute([$websiteId, $companyId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Delete user by ID
    public function delete($id)
    {
        $stmt = $this->conn->prepare("DELETE FROM User WHERE id = ?");
        return $stmt->execute([$id]);
    }

    // Password stuff stays the same
    public function verifyPassword($password, $actualPassword)
    {
        return password_verify($password, $actualPassword);
    }

    public function updatePassword($id, $newPassword, $updatedBy)
    {
        $query = "UPDATE User SET password = ?, updated_by = ?, updated_at = NOW() WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        return $stmt->execute([$hashedPassword, $updatedBy, $id]);
    }
}
