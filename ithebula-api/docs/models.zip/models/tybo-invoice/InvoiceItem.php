<?php
class InvoiceItem
{
    public $name;
    public $description;
    public $quantity;
    public $frequency;
    public $unitPrice;
    public $totalPrice;
    public $taxRate;
    public $taxAmount;
    public $notes;
    public $serviceId;

    public function __construct($data)
    {
        // Allow both array/object
        $ob = is_array($data) ? (object) $data : $data;
        $this->name = $ob->name ?? '';
        $this->description = $ob->description ?? '';
        $this->quantity = $ob->quantity ?? 1;
        $this->frequency = $ob->frequency ?? '';
        $this->unitPrice = $ob->unitPrice ?? $ob->unit_price ?? 0.0;
        $this->totalPrice = $ob->totalPrice ?? $ob->total_price ?? 0.0;
        $this->taxRate = $ob->taxRate ?? $ob->tax_rate ?? 0.0;
        $this->taxAmount = $ob->taxAmount ?? $ob->tax_amount ?? 0.0;
        $this->notes = $ob->notes ?? '';
        $this->serviceId = $ob->serviceId ?? $ob->service_id ?? null;
    }
}
