<?php
require_once 'Client.php';
require_once 'Company.php';
require_once 'InvoiceItem.php'; // Ensure you load this too

class Invoice
{
    public $type;
    public $number;
    public $clientId;
    public $client;       // Client object
    public $issueDate;
    public $dueDate;
    public $status;
    public $notes;
    /** @var InvoiceItem[] */
    public $items = [];   // array of InvoiceItem
    public $subtotal;
    public $tax;
    public $total;
    public $discount;
    public $currency;
    public $terms;
    public $organizationId;
    public Company $company;

    /**
     * @param array|object $data - Invoice data array/object
     * @param Company|null $company - Company object with metadata
     */
    public function __construct($data, $company)
    {
        $this->company = new Company($company);

        // Allow data as array or object
        $ob = is_array($data) ? (object) $data : $data;
        $this->type = $ob->type ?? 'invoice';
        $this->number = $ob->number ?? '';
        $this->clientId = $ob->clientId ?? $ob->client_id ?? null;

        // Support both direct client or nested '_client'
        if (isset($ob->client)) {
            $this->client = $ob->client instanceof Client ? $ob->client : new Client($ob->client);
        } elseif (isset($ob->_client)) {
            $this->client = new Client(is_array($ob->_client) && isset($ob->_client['data']) ? $ob->_client['data'] : $ob->_client);
        } else {
            $this->client = null;
        }

        $this->issueDate = $ob->issueDate ?? $ob->issue_date ?? '';
        $this->dueDate = $ob->dueDate ?? $ob->due_date ?? '';
        $this->status = $ob->status ?? 'draft';
        $this->notes = $ob->notes ?? '';
        $this->subtotal = $ob->subtotal ?? 0.0;
        $this->tax = $ob->tax ?? 0.0;
        $this->total = $ob->total ?? 0.0;
        $this->discount = $ob->discount ?? 0.0;
        $this->currency = $ob->currency ?? 'R';
        $this->terms = $ob->terms ?? '';
        $this->organizationId = $ob->organizationId ?? $ob->organization_id ?? 0;

        // Accept both items as objects or array under '_items'
        if (isset($ob->items) && is_array($ob->items)) {
            foreach ($ob->items as $itemData) {
                $this->items[] = $itemData instanceof InvoiceItem ? $itemData : new InvoiceItem($itemData);
            }
        } elseif (isset($ob->_items) && is_array($ob->_items)) {
            foreach ($ob->_items as $item) {
                $itemData = is_array($item) && isset($item['data']) ? $item['data'] : $item;
                $this->items[] = new InvoiceItem($itemData);
            }
        }
    }

    public function getStatusLabel()
    {
        return ucfirst($this->status);
    }

    public function getTotalFormatted()
    {
        return $this->currency . number_format($this->total, 2);
    }

    // You can add more helpers (e.g. for subtotal, date formatting, etc.)
}
