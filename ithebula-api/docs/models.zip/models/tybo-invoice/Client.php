<?php
class Client
{
    public $name;
    public $email;
    public $phone;
    public $companyName;
    public $companyVat;
    public $address;
    public $notes;
    public $tags;

    public function __construct($data)
    {
        $ob = is_array($data) ? (object) $data : $data;
        $this->name = $ob->name ?? '';
        $this->email = $ob->email ?? '';
        $this->phone = $ob->phone ?? '';
        $this->companyName = $ob->companyName ?? $ob->company_name ?? '';
        $this->companyVat = $ob->companyVat ?? $ob->company_vat ?? '';
        $this->address = $ob->address ?? '';
        $this->notes = $ob->notes ?? '';
        $this->tags = $ob->tags ?? [];
    }
}
